﻿namespace SARA_MINIPROJECT_II
{
    partial class EducationDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.degree = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.NOI = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Uni = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.YOP = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.per = new System.Windows.Forms.MaskedTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Degree";
            // 
            // degree
            // 
            this.degree.Cursor = System.Windows.Forms.Cursors.Default;
            this.degree.Location = new System.Drawing.Point(229, 115);
            this.degree.Name = "degree";
            this.degree.Size = new System.Drawing.Size(326, 22);
            this.degree.TabIndex = 1;
            this.degree.TextChanged += new System.EventHandler(this.degree_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name of Institute";
            // 
            // NOI
            // 
            this.NOI.Location = new System.Drawing.Point(229, 186);
            this.NOI.Name = "NOI";
            this.NOI.Size = new System.Drawing.Size(326, 22);
            this.NOI.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(68, 281);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "University";
            // 
            // Uni
            // 
            this.Uni.Location = new System.Drawing.Point(229, 276);
            this.Uni.Name = "Uni";
            this.Uni.Size = new System.Drawing.Size(326, 22);
            this.Uni.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 356);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "year of passsing";
            // 
            // YOP
            // 
            this.YOP.FormattingEnabled = true;
            this.YOP.Location = new System.Drawing.Point(229, 356);
            this.YOP.Name = "YOP";
            this.YOP.Size = new System.Drawing.Size(121, 24);
            this.YOP.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(68, 431);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Percentage";
            // 
            // per
            // 
            this.per.Location = new System.Drawing.Point(229, 416);
            this.per.Mask = "00.00 %";
            this.per.Name = "per";
            this.per.Size = new System.Drawing.Size(121, 22);
            this.per.TabIndex = 9;
            this.per.ValidatingType = typeof(int);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(406, 560);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "ADD";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(843, 521);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(263, 120);
            this.button2.TabIndex = 11;
            this.button2.Text = "FINISH";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(761, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 17);
            this.label6.TabIndex = 12;
            // 
            // EducationDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 653);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.per);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.YOP);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Uni);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.NOI);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.degree);
            this.Controls.Add(this.label1);
            this.Name = "EducationDetails";
            this.Text = "EducationDetails";
            this.Load += new System.EventHandler(this.EducationDetails_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox degree;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox NOI;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Uni;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox YOP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox per;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label6;
    }
}