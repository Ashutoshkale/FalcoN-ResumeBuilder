﻿namespace SARA_MINIPROJECT_II
{
    internal class ArrayList<T>
    {
    }
}