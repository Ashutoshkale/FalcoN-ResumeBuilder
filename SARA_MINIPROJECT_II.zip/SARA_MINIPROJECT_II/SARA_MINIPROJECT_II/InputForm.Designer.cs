﻿namespace SARA_MINIPROJECT_II
{
    partial class InputForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InputForm));
            this.label1 = new System.Windows.Forms.Label();
            this.FN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.MN = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.LN = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.phno = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.homeadd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.city = new System.Windows.Forms.TextBox();
            this.state = new System.Windows.Forms.TextBox();
            this.country = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.zipcode = new System.Windows.Forms.MaskedTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.streetname = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.objective = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.prodes3 = new System.Windows.Forms.RichTextBox();
            this.prodes2 = new System.Windows.Forms.RichTextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.prodes1 = new System.Windows.Forms.RichTextBox();
            this.pro2 = new System.Windows.Forms.TextBox();
            this.pro3 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.pro1 = new System.Windows.Forms.TextBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.label24 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label33 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // FN
            // 
            this.FN.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.FN.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.AllUrl;
            this.FN.BackColor = System.Drawing.Color.White;
            this.FN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            resources.ApplyResources(this.FN, "FN");
            this.FN.Name = "FN";
            this.FN.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            // 
            // MN
            // 
            this.MN.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.MN.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.AllUrl;
            this.MN.BackColor = System.Drawing.Color.White;
            this.MN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            resources.ApplyResources(this.MN, "MN");
            this.MN.Name = "MN";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // LN
            // 
            this.LN.BackColor = System.Drawing.Color.White;
            this.LN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            resources.ApplyResources(this.LN, "LN");
            this.LN.Name = "LN";
            this.LN.TextChanged += new System.EventHandler(this.LN_TextChanged);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Name = "label4";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // email
            // 
            this.email.BackColor = System.Drawing.Color.White;
            this.email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.email, "email");
            this.email.Name = "email";
            this.email.TextChanged += new System.EventHandler(this.email_TextChanged);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Name = "label5";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.Tan;
            this.label6.Name = "label6";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // phno
            // 
            this.phno.AsciiOnly = true;
            this.phno.BackColor = System.Drawing.Color.White;
            this.phno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.phno, "phno");
            this.phno.Name = "phno";
            this.phno.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.phno_MaskInputRejected);
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.Color.Tan;
            this.label7.Name = "label7";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Name = "label8";
            // 
            // homeadd
            // 
            this.homeadd.BackColor = System.Drawing.Color.White;
            this.homeadd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.homeadd, "homeadd");
            this.homeadd.Name = "homeadd";
            this.homeadd.TextChanged += new System.EventHandler(this.homeadd_TextChanged);
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Name = "label9";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Name = "label10";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Name = "label11";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // city
            // 
            this.city.BackColor = System.Drawing.Color.White;
            this.city.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.city, "city");
            this.city.Name = "city";
            this.city.TextChanged += new System.EventHandler(this.city_TextChanged);
            // 
            // state
            // 
            this.state.BackColor = System.Drawing.Color.White;
            this.state.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.state, "state");
            this.state.Name = "state";
            this.state.TextChanged += new System.EventHandler(this.state_TextChanged);
            // 
            // country
            // 
            this.country.BackColor = System.Drawing.Color.White;
            this.country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.country, "country");
            this.country.FormattingEnabled = true;
            this.country.Items.AddRange(new object[] {
            resources.GetString("country.Items"),
            resources.GetString("country.Items1"),
            resources.GetString("country.Items2"),
            resources.GetString("country.Items3"),
            resources.GetString("country.Items4"),
            resources.GetString("country.Items5"),
            resources.GetString("country.Items6"),
            resources.GetString("country.Items7"),
            resources.GetString("country.Items8"),
            resources.GetString("country.Items9"),
            resources.GetString("country.Items10"),
            resources.GetString("country.Items11"),
            resources.GetString("country.Items12"),
            resources.GetString("country.Items13"),
            resources.GetString("country.Items14"),
            resources.GetString("country.Items15"),
            resources.GetString("country.Items16"),
            resources.GetString("country.Items17"),
            resources.GetString("country.Items18"),
            resources.GetString("country.Items19"),
            resources.GetString("country.Items20"),
            resources.GetString("country.Items21"),
            resources.GetString("country.Items22"),
            resources.GetString("country.Items23"),
            resources.GetString("country.Items24"),
            resources.GetString("country.Items25"),
            resources.GetString("country.Items26"),
            resources.GetString("country.Items27"),
            resources.GetString("country.Items28"),
            resources.GetString("country.Items29"),
            resources.GetString("country.Items30"),
            resources.GetString("country.Items31"),
            resources.GetString("country.Items32"),
            resources.GetString("country.Items33"),
            resources.GetString("country.Items34"),
            resources.GetString("country.Items35"),
            resources.GetString("country.Items36"),
            resources.GetString("country.Items37"),
            resources.GetString("country.Items38"),
            resources.GetString("country.Items39"),
            resources.GetString("country.Items40"),
            resources.GetString("country.Items41"),
            resources.GetString("country.Items42"),
            resources.GetString("country.Items43"),
            resources.GetString("country.Items44"),
            resources.GetString("country.Items45"),
            resources.GetString("country.Items46"),
            resources.GetString("country.Items47"),
            resources.GetString("country.Items48"),
            resources.GetString("country.Items49"),
            resources.GetString("country.Items50"),
            resources.GetString("country.Items51"),
            resources.GetString("country.Items52"),
            resources.GetString("country.Items53"),
            resources.GetString("country.Items54"),
            resources.GetString("country.Items55"),
            resources.GetString("country.Items56"),
            resources.GetString("country.Items57"),
            resources.GetString("country.Items58"),
            resources.GetString("country.Items59"),
            resources.GetString("country.Items60"),
            resources.GetString("country.Items61"),
            resources.GetString("country.Items62"),
            resources.GetString("country.Items63"),
            resources.GetString("country.Items64"),
            resources.GetString("country.Items65"),
            resources.GetString("country.Items66"),
            resources.GetString("country.Items67"),
            resources.GetString("country.Items68"),
            resources.GetString("country.Items69"),
            resources.GetString("country.Items70"),
            resources.GetString("country.Items71"),
            resources.GetString("country.Items72"),
            resources.GetString("country.Items73"),
            resources.GetString("country.Items74"),
            resources.GetString("country.Items75"),
            resources.GetString("country.Items76"),
            resources.GetString("country.Items77"),
            resources.GetString("country.Items78"),
            resources.GetString("country.Items79"),
            resources.GetString("country.Items80"),
            resources.GetString("country.Items81"),
            resources.GetString("country.Items82"),
            resources.GetString("country.Items83"),
            resources.GetString("country.Items84"),
            resources.GetString("country.Items85"),
            resources.GetString("country.Items86"),
            resources.GetString("country.Items87"),
            resources.GetString("country.Items88"),
            resources.GetString("country.Items89"),
            resources.GetString("country.Items90"),
            resources.GetString("country.Items91"),
            resources.GetString("country.Items92"),
            resources.GetString("country.Items93"),
            resources.GetString("country.Items94"),
            resources.GetString("country.Items95"),
            resources.GetString("country.Items96"),
            resources.GetString("country.Items97"),
            resources.GetString("country.Items98"),
            resources.GetString("country.Items99"),
            resources.GetString("country.Items100"),
            resources.GetString("country.Items101"),
            resources.GetString("country.Items102"),
            resources.GetString("country.Items103"),
            resources.GetString("country.Items104"),
            resources.GetString("country.Items105"),
            resources.GetString("country.Items106"),
            resources.GetString("country.Items107"),
            resources.GetString("country.Items108"),
            resources.GetString("country.Items109"),
            resources.GetString("country.Items110"),
            resources.GetString("country.Items111"),
            resources.GetString("country.Items112"),
            resources.GetString("country.Items113"),
            resources.GetString("country.Items114"),
            resources.GetString("country.Items115"),
            resources.GetString("country.Items116"),
            resources.GetString("country.Items117"),
            resources.GetString("country.Items118"),
            resources.GetString("country.Items119"),
            resources.GetString("country.Items120"),
            resources.GetString("country.Items121"),
            resources.GetString("country.Items122"),
            resources.GetString("country.Items123"),
            resources.GetString("country.Items124"),
            resources.GetString("country.Items125"),
            resources.GetString("country.Items126"),
            resources.GetString("country.Items127"),
            resources.GetString("country.Items128"),
            resources.GetString("country.Items129"),
            resources.GetString("country.Items130"),
            resources.GetString("country.Items131"),
            resources.GetString("country.Items132"),
            resources.GetString("country.Items133"),
            resources.GetString("country.Items134"),
            resources.GetString("country.Items135"),
            resources.GetString("country.Items136"),
            resources.GetString("country.Items137"),
            resources.GetString("country.Items138"),
            resources.GetString("country.Items139"),
            resources.GetString("country.Items140"),
            resources.GetString("country.Items141"),
            resources.GetString("country.Items142"),
            resources.GetString("country.Items143"),
            resources.GetString("country.Items144"),
            resources.GetString("country.Items145"),
            resources.GetString("country.Items146"),
            resources.GetString("country.Items147"),
            resources.GetString("country.Items148"),
            resources.GetString("country.Items149"),
            resources.GetString("country.Items150"),
            resources.GetString("country.Items151"),
            resources.GetString("country.Items152"),
            resources.GetString("country.Items153"),
            resources.GetString("country.Items154"),
            resources.GetString("country.Items155"),
            resources.GetString("country.Items156"),
            resources.GetString("country.Items157"),
            resources.GetString("country.Items158"),
            resources.GetString("country.Items159"),
            resources.GetString("country.Items160"),
            resources.GetString("country.Items161"),
            resources.GetString("country.Items162"),
            resources.GetString("country.Items163"),
            resources.GetString("country.Items164"),
            resources.GetString("country.Items165"),
            resources.GetString("country.Items166"),
            resources.GetString("country.Items167"),
            resources.GetString("country.Items168"),
            resources.GetString("country.Items169"),
            resources.GetString("country.Items170"),
            resources.GetString("country.Items171"),
            resources.GetString("country.Items172"),
            resources.GetString("country.Items173"),
            resources.GetString("country.Items174"),
            resources.GetString("country.Items175"),
            resources.GetString("country.Items176"),
            resources.GetString("country.Items177"),
            resources.GetString("country.Items178"),
            resources.GetString("country.Items179"),
            resources.GetString("country.Items180"),
            resources.GetString("country.Items181"),
            resources.GetString("country.Items182"),
            resources.GetString("country.Items183"),
            resources.GetString("country.Items184"),
            resources.GetString("country.Items185"),
            resources.GetString("country.Items186"),
            resources.GetString("country.Items187"),
            resources.GetString("country.Items188"),
            resources.GetString("country.Items189"),
            resources.GetString("country.Items190"),
            resources.GetString("country.Items191"),
            resources.GetString("country.Items192"),
            resources.GetString("country.Items193"),
            resources.GetString("country.Items194"),
            resources.GetString("country.Items195"),
            resources.GetString("country.Items196"),
            resources.GetString("country.Items197")});
            this.country.Name = "country";
            this.country.SelectedIndexChanged += new System.EventHandler(this.country_SelectedIndexChanged);
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Name = "label12";
            // 
            // zipcode
            // 
            this.zipcode.BackColor = System.Drawing.Color.White;
            this.zipcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.zipcode, "zipcode");
            this.zipcode.Name = "zipcode";
            this.zipcode.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.zipcode_MaskInputRejected);
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Name = "label13";
            // 
            // streetname
            // 
            this.streetname.BackColor = System.Drawing.Color.White;
            this.streetname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.streetname, "streetname");
            this.streetname.Name = "streetname";
            this.streetname.TextChanged += new System.EventHandler(this.streetname_TextChanged);
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.ForeColor = System.Drawing.Color.Tan;
            this.label14.Name = "label14";
            this.toolTip1.SetToolTip(this.label14, resources.GetString("label14.ToolTip"));
            // 
            // objective
            // 
            this.objective.BackColor = System.Drawing.Color.White;
            this.objective.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.objective, "objective");
            this.objective.Name = "objective";
            this.objective.TextChanged += new System.EventHandler(this.objective_TextChanged);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            resources.ApplyResources(this.button5, "button5");
            this.button5.Name = "button5";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Name = "label19";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.label19);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.ForeColor = System.Drawing.Color.Tan;
            this.label26.Name = "label26";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.White;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox10, "textBox10");
            this.textBox10.Name = "textBox10";
            this.textBox10.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Name = "label18";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.Name = "textBox4";
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.White;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox9, "textBox9");
            this.textBox9.Name = "textBox9";
            // 
            // label27
            // 
            resources.ApplyResources(this.label27, "label27");
            this.label27.Name = "label27";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Controls.Add(this.tableLayoutPanel2);
            this.panel3.Controls.Add(this.textBox29);
            this.panel3.Controls.Add(this.textBox28);
            this.panel3.Controls.Add(this.textBox26);
            this.panel3.Controls.Add(this.textBox21);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.textBox11);
            this.panel3.Controls.Add(this.label27);
            this.panel3.Controls.Add(this.textBox9);
            this.panel3.Controls.Add(this.button5);
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.textBox10);
            this.panel3.Name = "panel3";
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // tableLayoutPanel2
            // 
            resources.ApplyResources(this.tableLayoutPanel2, "tableLayoutPanel2");
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel2.Controls.Add(this.prodes3, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.prodes2, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label29, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.comboBox7, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.comboBox8, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.prodes1, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.pro2, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.pro3, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label28, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.pro1, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.comboBox6, 0, 1);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            // 
            // prodes3
            // 
            this.prodes3.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.prodes3, "prodes3");
            this.prodes3.Name = "prodes3";
            // 
            // prodes2
            // 
            this.prodes2.BackColor = System.Drawing.Color.White;
            this.prodes2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.prodes2, "prodes2");
            this.prodes2.Name = "prodes2";
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Name = "label29";
            // 
            // comboBox7
            // 
            this.comboBox7.BackColor = System.Drawing.Color.SkyBlue;
            this.comboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.comboBox7, "comboBox7");
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            resources.GetString("comboBox7.Items"),
            resources.GetString("comboBox7.Items1"),
            resources.GetString("comboBox7.Items2"),
            resources.GetString("comboBox7.Items3"),
            resources.GetString("comboBox7.Items4")});
            this.comboBox7.Name = "comboBox7";
            // 
            // comboBox8
            // 
            this.comboBox8.BackColor = System.Drawing.Color.SkyBlue;
            this.comboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.comboBox8, "comboBox8");
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            resources.GetString("comboBox8.Items"),
            resources.GetString("comboBox8.Items1"),
            resources.GetString("comboBox8.Items2"),
            resources.GetString("comboBox8.Items3"),
            resources.GetString("comboBox8.Items4")});
            this.comboBox8.Name = "comboBox8";
            // 
            // prodes1
            // 
            this.prodes1.BackColor = System.Drawing.Color.White;
            this.prodes1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.prodes1, "prodes1");
            this.prodes1.Name = "prodes1";
            this.prodes1.TextChanged += new System.EventHandler(this.prodes1_TextChanged);
            // 
            // pro2
            // 
            this.pro2.BackColor = System.Drawing.Color.White;
            this.pro2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.pro2, "pro2");
            this.pro2.Name = "pro2";
            this.pro2.TextChanged += new System.EventHandler(this.pro2_TextChanged);
            // 
            // pro3
            // 
            this.pro3.BackColor = System.Drawing.Color.White;
            this.pro3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.pro3, "pro3");
            this.pro3.Name = "pro3";
            this.pro3.TextChanged += new System.EventHandler(this.pro3_TextChanged);
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Name = "label17";
            // 
            // label28
            // 
            resources.ApplyResources(this.label28, "label28");
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Name = "label28";
            // 
            // pro1
            // 
            this.pro1.BackColor = System.Drawing.Color.White;
            this.pro1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.pro1, "pro1");
            this.pro1.Name = "pro1";
            this.pro1.TextChanged += new System.EventHandler(this.pro1_TextChanged);
            // 
            // comboBox6
            // 
            this.comboBox6.BackColor = System.Drawing.Color.SkyBlue;
            this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.comboBox6, "comboBox6");
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            resources.GetString("comboBox6.Items"),
            resources.GetString("comboBox6.Items1"),
            resources.GetString("comboBox6.Items2"),
            resources.GetString("comboBox6.Items3"),
            resources.GetString("comboBox6.Items4")});
            this.comboBox6.Name = "comboBox6";
            // 
            // textBox29
            // 
            this.textBox29.BackColor = System.Drawing.Color.White;
            this.textBox29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox29, "textBox29");
            this.textBox29.Name = "textBox29";
            // 
            // textBox28
            // 
            this.textBox28.BackColor = System.Drawing.Color.White;
            this.textBox28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox28, "textBox28");
            this.textBox28.Name = "textBox28";
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.Color.White;
            this.textBox26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox26, "textBox26");
            this.textBox26.Name = "textBox26";
            this.textBox26.TextChanged += new System.EventHandler(this.textBox26_TextChanged);
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.Color.White;
            this.textBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox21, "textBox21");
            this.textBox21.Name = "textBox21";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Name = "label15";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.White;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox11, "textBox11");
            this.textBox11.Name = "textBox11";
            this.textBox11.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label16.Name = "label16";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // folderBrowserDialog1
            // 
            this.folderBrowserDialog1.HelpRequest += new System.EventHandler(this.folderBrowserDialog1_HelpRequest);
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Name = "label24";
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Name = "label20";
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.Color.White;
            this.textBox19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox19, "textBox19");
            this.textBox19.Name = "textBox19";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox2, "textBox2");
            this.textBox2.Name = "textBox2";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.White;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox7, "textBox7");
            this.textBox7.Name = "textBox7";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Name = "label21";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.comboBox1, "comboBox1");
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            resources.GetString("comboBox1.Items"),
            resources.GetString("comboBox1.Items1"),
            resources.GetString("comboBox1.Items2"),
            resources.GetString("comboBox1.Items3"),
            resources.GetString("comboBox1.Items4"),
            resources.GetString("comboBox1.Items5"),
            resources.GetString("comboBox1.Items6"),
            resources.GetString("comboBox1.Items7"),
            resources.GetString("comboBox1.Items8"),
            resources.GetString("comboBox1.Items9"),
            resources.GetString("comboBox1.Items10"),
            resources.GetString("comboBox1.Items11"),
            resources.GetString("comboBox1.Items12"),
            resources.GetString("comboBox1.Items13"),
            resources.GetString("comboBox1.Items14"),
            resources.GetString("comboBox1.Items15"),
            resources.GetString("comboBox1.Items16"),
            resources.GetString("comboBox1.Items17"),
            resources.GetString("comboBox1.Items18"),
            resources.GetString("comboBox1.Items19"),
            resources.GetString("comboBox1.Items20"),
            resources.GetString("comboBox1.Items21"),
            resources.GetString("comboBox1.Items22"),
            resources.GetString("comboBox1.Items23"),
            resources.GetString("comboBox1.Items24"),
            resources.GetString("comboBox1.Items25"),
            resources.GetString("comboBox1.Items26"),
            resources.GetString("comboBox1.Items27"),
            resources.GetString("comboBox1.Items28"),
            resources.GetString("comboBox1.Items29"),
            resources.GetString("comboBox1.Items30"),
            resources.GetString("comboBox1.Items31"),
            resources.GetString("comboBox1.Items32"),
            resources.GetString("comboBox1.Items33"),
            resources.GetString("comboBox1.Items34"),
            resources.GetString("comboBox1.Items35"),
            resources.GetString("comboBox1.Items36"),
            resources.GetString("comboBox1.Items37"),
            resources.GetString("comboBox1.Items38"),
            resources.GetString("comboBox1.Items39"),
            resources.GetString("comboBox1.Items40"),
            resources.GetString("comboBox1.Items41"),
            resources.GetString("comboBox1.Items42"),
            resources.GetString("comboBox1.Items43"),
            resources.GetString("comboBox1.Items44"),
            resources.GetString("comboBox1.Items45"),
            resources.GetString("comboBox1.Items46"),
            resources.GetString("comboBox1.Items47"),
            resources.GetString("comboBox1.Items48"),
            resources.GetString("comboBox1.Items49")});
            this.comboBox1.Name = "comboBox1";
            // 
            // textBox1
            // 
            this.textBox1.AutoCompleteCustomSource.AddRange(new string[] {
            resources.GetString("textBox1.AutoCompleteCustomSource"),
            resources.GetString("textBox1.AutoCompleteCustomSource1"),
            resources.GetString("textBox1.AutoCompleteCustomSource2"),
            resources.GetString("textBox1.AutoCompleteCustomSource3"),
            resources.GetString("textBox1.AutoCompleteCustomSource4"),
            resources.GetString("textBox1.AutoCompleteCustomSource5")});
            this.textBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.Name = "textBox1";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Name = "label22";
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Name = "label23";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.Name = "textBox3";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.White;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox5, "textBox5");
            this.textBox5.Name = "textBox5";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.White;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox6, "textBox6");
            this.textBox6.Name = "textBox6";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.White;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox8, "textBox8");
            this.textBox8.Name = "textBox8";
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.White;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox12, "textBox12");
            this.textBox12.Name = "textBox12";
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.White;
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox13, "textBox13");
            this.textBox13.Name = "textBox13";
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.Color.White;
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox14, "textBox14");
            this.textBox14.Name = "textBox14";
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.White;
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox15, "textBox15");
            this.textBox15.Name = "textBox15";
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.Color.White;
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox17, "textBox17");
            this.textBox17.Name = "textBox17";
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.Color.White;
            this.textBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox18, "textBox18");
            this.textBox18.Name = "textBox18";
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.Color.White;
            this.textBox20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox20, "textBox20");
            this.textBox20.Name = "textBox20";
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.Color.White;
            this.textBox22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox22, "textBox22");
            this.textBox22.Name = "textBox22";
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.Color.White;
            this.textBox23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox23, "textBox23");
            this.textBox23.Name = "textBox23";
            // 
            // textBox24
            // 
            this.textBox24.BackColor = System.Drawing.Color.White;
            this.textBox24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox24, "textBox24");
            this.textBox24.Name = "textBox24";
            this.textBox24.TextChanged += new System.EventHandler(this.textBox24_TextChanged);
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.Color.White;
            this.textBox25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox25, "textBox25");
            this.textBox25.Name = "textBox25";
            // 
            // textBox27
            // 
            this.textBox27.BackColor = System.Drawing.Color.White;
            this.textBox27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.textBox27, "textBox27");
            this.textBox27.Name = "textBox27";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.comboBox2, "comboBox2");
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            resources.GetString("comboBox2.Items"),
            resources.GetString("comboBox2.Items1"),
            resources.GetString("comboBox2.Items2"),
            resources.GetString("comboBox2.Items3"),
            resources.GetString("comboBox2.Items4"),
            resources.GetString("comboBox2.Items5"),
            resources.GetString("comboBox2.Items6"),
            resources.GetString("comboBox2.Items7"),
            resources.GetString("comboBox2.Items8"),
            resources.GetString("comboBox2.Items9"),
            resources.GetString("comboBox2.Items10"),
            resources.GetString("comboBox2.Items11"),
            resources.GetString("comboBox2.Items12"),
            resources.GetString("comboBox2.Items13"),
            resources.GetString("comboBox2.Items14"),
            resources.GetString("comboBox2.Items15"),
            resources.GetString("comboBox2.Items16"),
            resources.GetString("comboBox2.Items17"),
            resources.GetString("comboBox2.Items18"),
            resources.GetString("comboBox2.Items19"),
            resources.GetString("comboBox2.Items20"),
            resources.GetString("comboBox2.Items21"),
            resources.GetString("comboBox2.Items22"),
            resources.GetString("comboBox2.Items23"),
            resources.GetString("comboBox2.Items24"),
            resources.GetString("comboBox2.Items25"),
            resources.GetString("comboBox2.Items26"),
            resources.GetString("comboBox2.Items27"),
            resources.GetString("comboBox2.Items28"),
            resources.GetString("comboBox2.Items29"),
            resources.GetString("comboBox2.Items30"),
            resources.GetString("comboBox2.Items31"),
            resources.GetString("comboBox2.Items32"),
            resources.GetString("comboBox2.Items33"),
            resources.GetString("comboBox2.Items34"),
            resources.GetString("comboBox2.Items35"),
            resources.GetString("comboBox2.Items36"),
            resources.GetString("comboBox2.Items37"),
            resources.GetString("comboBox2.Items38"),
            resources.GetString("comboBox2.Items39"),
            resources.GetString("comboBox2.Items40"),
            resources.GetString("comboBox2.Items41"),
            resources.GetString("comboBox2.Items42"),
            resources.GetString("comboBox2.Items43"),
            resources.GetString("comboBox2.Items44"),
            resources.GetString("comboBox2.Items45"),
            resources.GetString("comboBox2.Items46"),
            resources.GetString("comboBox2.Items47"),
            resources.GetString("comboBox2.Items48"),
            resources.GetString("comboBox2.Items49")});
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.comboBox3, "comboBox3");
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            resources.GetString("comboBox3.Items"),
            resources.GetString("comboBox3.Items1"),
            resources.GetString("comboBox3.Items2"),
            resources.GetString("comboBox3.Items3"),
            resources.GetString("comboBox3.Items4"),
            resources.GetString("comboBox3.Items5"),
            resources.GetString("comboBox3.Items6"),
            resources.GetString("comboBox3.Items7"),
            resources.GetString("comboBox3.Items8"),
            resources.GetString("comboBox3.Items9"),
            resources.GetString("comboBox3.Items10"),
            resources.GetString("comboBox3.Items11"),
            resources.GetString("comboBox3.Items12"),
            resources.GetString("comboBox3.Items13"),
            resources.GetString("comboBox3.Items14"),
            resources.GetString("comboBox3.Items15"),
            resources.GetString("comboBox3.Items16"),
            resources.GetString("comboBox3.Items17"),
            resources.GetString("comboBox3.Items18"),
            resources.GetString("comboBox3.Items19"),
            resources.GetString("comboBox3.Items20"),
            resources.GetString("comboBox3.Items21"),
            resources.GetString("comboBox3.Items22"),
            resources.GetString("comboBox3.Items23"),
            resources.GetString("comboBox3.Items24"),
            resources.GetString("comboBox3.Items25"),
            resources.GetString("comboBox3.Items26"),
            resources.GetString("comboBox3.Items27"),
            resources.GetString("comboBox3.Items28"),
            resources.GetString("comboBox3.Items29"),
            resources.GetString("comboBox3.Items30"),
            resources.GetString("comboBox3.Items31"),
            resources.GetString("comboBox3.Items32"),
            resources.GetString("comboBox3.Items33"),
            resources.GetString("comboBox3.Items34"),
            resources.GetString("comboBox3.Items35"),
            resources.GetString("comboBox3.Items36"),
            resources.GetString("comboBox3.Items37"),
            resources.GetString("comboBox3.Items38"),
            resources.GetString("comboBox3.Items39"),
            resources.GetString("comboBox3.Items40"),
            resources.GetString("comboBox3.Items41"),
            resources.GetString("comboBox3.Items42"),
            resources.GetString("comboBox3.Items43"),
            resources.GetString("comboBox3.Items44"),
            resources.GetString("comboBox3.Items45"),
            resources.GetString("comboBox3.Items46"),
            resources.GetString("comboBox3.Items47"),
            resources.GetString("comboBox3.Items48"),
            resources.GetString("comboBox3.Items49")});
            this.comboBox3.Name = "comboBox3";
            // 
            // comboBox4
            // 
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.comboBox4, "comboBox4");
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            resources.GetString("comboBox4.Items"),
            resources.GetString("comboBox4.Items1"),
            resources.GetString("comboBox4.Items2"),
            resources.GetString("comboBox4.Items3"),
            resources.GetString("comboBox4.Items4"),
            resources.GetString("comboBox4.Items5"),
            resources.GetString("comboBox4.Items6"),
            resources.GetString("comboBox4.Items7"),
            resources.GetString("comboBox4.Items8"),
            resources.GetString("comboBox4.Items9"),
            resources.GetString("comboBox4.Items10"),
            resources.GetString("comboBox4.Items11"),
            resources.GetString("comboBox4.Items12"),
            resources.GetString("comboBox4.Items13"),
            resources.GetString("comboBox4.Items14"),
            resources.GetString("comboBox4.Items15"),
            resources.GetString("comboBox4.Items16"),
            resources.GetString("comboBox4.Items17"),
            resources.GetString("comboBox4.Items18"),
            resources.GetString("comboBox4.Items19"),
            resources.GetString("comboBox4.Items20"),
            resources.GetString("comboBox4.Items21"),
            resources.GetString("comboBox4.Items22"),
            resources.GetString("comboBox4.Items23"),
            resources.GetString("comboBox4.Items24"),
            resources.GetString("comboBox4.Items25"),
            resources.GetString("comboBox4.Items26"),
            resources.GetString("comboBox4.Items27"),
            resources.GetString("comboBox4.Items28"),
            resources.GetString("comboBox4.Items29"),
            resources.GetString("comboBox4.Items30"),
            resources.GetString("comboBox4.Items31"),
            resources.GetString("comboBox4.Items32"),
            resources.GetString("comboBox4.Items33"),
            resources.GetString("comboBox4.Items34"),
            resources.GetString("comboBox4.Items35"),
            resources.GetString("comboBox4.Items36"),
            resources.GetString("comboBox4.Items37"),
            resources.GetString("comboBox4.Items38"),
            resources.GetString("comboBox4.Items39"),
            resources.GetString("comboBox4.Items40"),
            resources.GetString("comboBox4.Items41"),
            resources.GetString("comboBox4.Items42"),
            resources.GetString("comboBox4.Items43"),
            resources.GetString("comboBox4.Items44"),
            resources.GetString("comboBox4.Items45"),
            resources.GetString("comboBox4.Items46"),
            resources.GetString("comboBox4.Items47"),
            resources.GetString("comboBox4.Items48"),
            resources.GetString("comboBox4.Items49"),
            resources.GetString("comboBox4.Items50"),
            resources.GetString("comboBox4.Items51"),
            resources.GetString("comboBox4.Items52"),
            resources.GetString("comboBox4.Items53"),
            resources.GetString("comboBox4.Items54"),
            resources.GetString("comboBox4.Items55")});
            this.comboBox4.Name = "comboBox4";
            // 
            // comboBox5
            // 
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.comboBox5, "comboBox5");
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            resources.GetString("comboBox5.Items"),
            resources.GetString("comboBox5.Items1"),
            resources.GetString("comboBox5.Items2"),
            resources.GetString("comboBox5.Items3"),
            resources.GetString("comboBox5.Items4"),
            resources.GetString("comboBox5.Items5"),
            resources.GetString("comboBox5.Items6"),
            resources.GetString("comboBox5.Items7"),
            resources.GetString("comboBox5.Items8"),
            resources.GetString("comboBox5.Items9"),
            resources.GetString("comboBox5.Items10"),
            resources.GetString("comboBox5.Items11"),
            resources.GetString("comboBox5.Items12"),
            resources.GetString("comboBox5.Items13"),
            resources.GetString("comboBox5.Items14"),
            resources.GetString("comboBox5.Items15"),
            resources.GetString("comboBox5.Items16"),
            resources.GetString("comboBox5.Items17"),
            resources.GetString("comboBox5.Items18"),
            resources.GetString("comboBox5.Items19"),
            resources.GetString("comboBox5.Items20"),
            resources.GetString("comboBox5.Items21"),
            resources.GetString("comboBox5.Items22"),
            resources.GetString("comboBox5.Items23"),
            resources.GetString("comboBox5.Items24"),
            resources.GetString("comboBox5.Items25"),
            resources.GetString("comboBox5.Items26"),
            resources.GetString("comboBox5.Items27"),
            resources.GetString("comboBox5.Items28"),
            resources.GetString("comboBox5.Items29"),
            resources.GetString("comboBox5.Items30"),
            resources.GetString("comboBox5.Items31"),
            resources.GetString("comboBox5.Items32"),
            resources.GetString("comboBox5.Items33"),
            resources.GetString("comboBox5.Items34"),
            resources.GetString("comboBox5.Items35"),
            resources.GetString("comboBox5.Items36"),
            resources.GetString("comboBox5.Items37"),
            resources.GetString("comboBox5.Items38"),
            resources.GetString("comboBox5.Items39"),
            resources.GetString("comboBox5.Items40"),
            resources.GetString("comboBox5.Items41"),
            resources.GetString("comboBox5.Items42"),
            resources.GetString("comboBox5.Items43"),
            resources.GetString("comboBox5.Items44"),
            resources.GetString("comboBox5.Items45"),
            resources.GetString("comboBox5.Items46"),
            resources.GetString("comboBox5.Items47"),
            resources.GetString("comboBox5.Items48"),
            resources.GetString("comboBox5.Items49")});
            this.comboBox5.Name = "comboBox5";
            // 
            // tableLayoutPanel1
            // 
            resources.ApplyResources(this.tableLayoutPanel1, "tableLayoutPanel1");
            this.tableLayoutPanel1.Controls.Add(this.comboBox5, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.comboBox4, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.comboBox3, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.comboBox2, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox27, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox25, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox24, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox23, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox22, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox20, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox18, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox17, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox15, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox14, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox13, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox12, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox8, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox6, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox5, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox3, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label23, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label22, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.comboBox1, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label21, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox7, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox19, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label24, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label30.Name = "label30";
            this.label30.Click += new System.EventHandler(this.label30_Click_1);
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.ForeColor = System.Drawing.Color.Gainsboro;
            this.label31.Name = "label31";
            // 
            // label32
            // 
            resources.ApplyResources(this.label32, "label32");
            this.label32.ForeColor = System.Drawing.Color.Gainsboro;
            this.label32.Name = "label32";
            this.label32.Click += new System.EventHandler(this.label32_Click_1);
            // 
            // toolTip1
            // 
            this.toolTip1.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip1_Popup);
            // 
            // label33
            // 
            resources.ApplyResources(this.label33, "label33");
            this.label33.BackColor = System.Drawing.Color.Black;
            this.label33.ForeColor = System.Drawing.Color.Red;
            this.label33.Name = "label33";
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // InputForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.objective);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.streetname);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.zipcode);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.country);
            this.Controls.Add(this.state);
            this.Controls.Add(this.city);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.homeadd);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.phno);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.email);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.LN);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.MN);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FN);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Name = "InputForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.InputForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.InputForm_FormClosed);
            this.Load += new System.EventHandler(this.InputForm_Load);
            this.Leave += new System.EventHandler(this.InputForm_Leave);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox FN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox MN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox LN;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox phno;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox homeadd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox city;
        private System.Windows.Forms.TextBox state;
        private System.Windows.Forms.ComboBox country;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.MaskedTextBox zipcode;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox streetname;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox objective;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.RichTextBox prodes3;
        private System.Windows.Forms.RichTextBox prodes2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.TextBox pro1;
        private System.Windows.Forms.TextBox pro2;
        private System.Windows.Forms.TextBox pro3;
        private System.Windows.Forms.RichTextBox prodes1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label33;
    }
}