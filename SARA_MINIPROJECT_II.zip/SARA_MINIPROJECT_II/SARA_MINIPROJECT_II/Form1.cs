﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using iTextSharp.text.pdf.draw;

namespace SARA_MINIPROJECT_II
{

    

    public partial class Form1 : Form
    {
        InputForm inputFormob = new InputForm();

        public Form1()
        {
            InitializeComponent();
            
            
        }


        

        private void Genrate_button_Click(object sender, EventArgs e)
        {
            //InputForm inputFormob = new InputForm();
            inputFormob.ShowDialog();


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
    }
}
