﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using iTextSharp.text.pdf.draw;
using System.Collections;

namespace SARA_MINIPROJECT_II
{
    public partial class InputForm : Form
    {

       


        public InputForm()
        {
           
            InitializeComponent();
        }
        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void InputForm_Load(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                
  

            //ed.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ProjectDATA pd = new ProjectDATA();
            pd.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            folderBrowserDialog1.ShowDialog();
            String folderName = folderBrowserDialog1.SelectedPath;
            string s2 = "\\";
            // MessageBox.Show(folderName);



            FileStream fs = new FileStream(folderName + s2 + FN.Text + ".pdf", FileMode.Create, FileAccess.Write, FileShare.None);
            // FileStream fs = new FileStream(FN.Text+".pdf", FileMode.Create, FileAccess.Write, FileShare.None);
            Document doc = new Document(PageSize.A4, 25, 25, 25, 25); //(pgSize, leftMargin, rightMargin, topMargin, bottomMargin);
            PdfWriter writer = PdfWriter.GetInstance(doc, fs);

            doc.Open();

            BaseFont bf = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);

            iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 12, iTextSharp.text.Font.BOLD); //Font.normal for normal...


            Paragraph p1 = new Paragraph(new Chunk(FN.Text + " " + MN.Text + " " + LN.Text, font));
            p1.Alignment = Element.ALIGN_CENTER;
            doc.Add(p1);


            // Address 

            BaseFont bf2 = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font font2 = new iTextSharp.text.Font(bf, 12, iTextSharp.text.Font.NORMAL);
            Paragraph p2 = new Paragraph(new Chunk(homeadd.Text + " " + streetname.Text + " " + city.Text + " " + state.Text + " " + country.Text + " " + zipcode.Text, font2));

            p2.Alignment = Element.ALIGN_CENTER;
            doc.Add(p2);

            //Email address and phone numner

            BaseFont bf3 = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font font3 = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.BOLD);
            Paragraph p3 = new Paragraph(new Chunk(email.Text + "    " + phno.Text, font3));

            p3.Alignment = Element.ALIGN_CENTER;
            doc.Add(p3);

            //Drawing Line 

            Paragraph p4 = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(0.0F, 100.0F, BaseColor.BLACK, Element.ALIGN_LEFT, 0)));
            doc.Add(p4);

            //End of Header part of resume

            /* HERE ALL CONTENTS OF RESUME */


            //OBJECTIVE TAG
            BaseFont bf4 = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font font4 = new iTextSharp.text.Font(bf, 16, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.UNDERLINE); //Font.normal for normal...

            Paragraph p5 = new Paragraph(new Chunk("OBEJCTIVE", font));

            p1.Alignment = Element.ALIGN_LEFT;
            doc.Add(p5);
            //STATIC TAG, Do need to edit anything here...

            BaseFont bf5 = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font font5 = new iTextSharp.text.Font(bf, 14, iTextSharp.text.Font.NORMAL);
            Paragraph p6 = new Paragraph(new Chunk(objective.Text, font5));
            p6.Alignment = Element.ALIGN_LEFT;
            p6.PaddingTop = 30f;
            doc.Add(p6); //OBJECTIVE TAB DONE...


            //STATIC AVOID CHANGES 
            BaseFont bf6 = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font font6 = new iTextSharp.text.Font(bf, 16, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.UNDERLINE);
            Paragraph p7 = new Paragraph(new Chunk("\n EDUCATION \n", font));
            p7.Alignment = Element.ALIGN_LEFT;
            p7.PaddingTop = 200;
            doc.Add(p7);
            // STATIC PART END 


            PdfPTable table = new PdfPTable(5) //number of rows... 
            { WidthPercentage = 100, RunDirection = PdfWriter.RUN_DIRECTION_LTR, ExtendLastRow = false };


            // table.TotalWidth = doc.PageSize.Width - doc.LeftMargin - doc.RightMargin;



            table.SpacingBefore = 20;

            table.HorizontalAlignment = Element.ALIGN_CENTER;




            table.AddCell("Degree");
            table.AddCell("Name of institute");
            table.AddCell("University");
            table.AddCell("Year of passing");
            table.AddCell("Score");

            // EducationDetails.


            //list.ForEach(Console.WriteLine);



            if (textBox1.Text != null)
                table.AddCell(textBox1.Text);

            if (textBox2.Text != null)
                table.AddCell(textBox2.Text);
            if (textBox3.Text != null)
                table.AddCell(textBox3.Text);
            table.AddCell(comboBox1.Text);
            if (textBox5.Text != null)
                table.AddCell(textBox5.Text);

            if (textBox6.Text != null)
                table.AddCell(textBox6.Text);
            if (textBox7.Text != null)
                table.AddCell(textBox7.Text);
            if (textBox8.Text != null)
                table.AddCell(textBox8.Text);
            table.AddCell(comboBox2.Text);
            if (textBox12.Text != null)
                table.AddCell(textBox12.Text);

            if (textBox13.Text != null)
                table.AddCell(textBox13.Text);
            if (textBox14.Text != null)
                table.AddCell(textBox14.Text);
            if (textBox15.Text != null)
                table.AddCell(textBox15.Text);
            table.AddCell(comboBox3.Text);
            if (textBox17.Text != null)
                table.AddCell(textBox17.Text);

            if (textBox18.Text != null)
                table.AddCell(textBox18.Text);
            if (textBox19.Text != null)
                table.AddCell(textBox19.Text);
            if (textBox20.Text != null)
                table.AddCell(textBox20.Text);
            table.AddCell(comboBox4.Text);
            if (textBox22.Text != null)
                table.AddCell(textBox22.Text);

            if (textBox23.Text != null)
                table.AddCell(textBox23.Text);
            if (textBox24.Text != null)
                table.AddCell(textBox24.Text);
            if (textBox25.Text != null)
                table.AddCell(textBox25.Text);
            table.AddCell(comboBox5.Text);
            if (textBox27.Text != null)
                table.AddCell(textBox27.Text);



            doc.Add(table);

            // Education TAB COMPETED 





            BaseFont bf7 = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font font7 = new iTextSharp.text.Font(bf, 16, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.UNDERLINE);
            Paragraph p8 = new Paragraph(new Chunk("\n PROJECTS \n ", font));
            p8.Alignment = Element.ALIGN_LEFT;
            doc.Add(p8);

            //STATIC POJECTS END
            
                BaseFont bf8 = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                iTextSharp.text.Font font8 = new iTextSharp.text.Font(bf8, 14, iTextSharp.text.Font.BOLDITALIC  );
            
                if (comboBox6.Text != null && pro1.Text != null && prodes1.Text != null)
                {
                    Paragraph p9 = new Paragraph(new Chunk("["+comboBox6.Text + "] :" + pro1.Text, font8)); //add seprate text for the title...
                    iTextSharp.text.Font boldFont = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 10);
                    

                    doc.Add(p9);

                    //ADD PROJECT DESCRIPTION 

                    BaseFont bf9 = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    iTextSharp.text.Font font9 = new iTextSharp.text.Font(bf9, 14, iTextSharp.text.Font.NORMAL);
                    Paragraph p10 = new Paragraph(new Chunk(prodes1.Text + "\n", font9));
                    p10.Alignment = Element.ALIGN_LEFT;
                    p10.PaddingTop = 30f;
                    doc.Add(p10);
                }

            if (comboBox7.Text != null && pro2.Text != null && prodes2.Text != null)
            {
                Paragraph p9 = new Paragraph(new Chunk("["+comboBox7.Text + "] :" + pro2.Text + "\n", font8)); //add seprate text for the title...
                iTextSharp.text.Font boldFont = FontFactory.GetFont(FontFactory.TIMES_ROMAN, 10);

                doc.Add(p9);

                //ADD PROJECT DESCRIPTION 

                BaseFont bf9 = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                iTextSharp.text.Font font9 = new iTextSharp.text.Font(bf9, 14, iTextSharp.text.Font.NORMAL);
                Paragraph p10 = new Paragraph(new Chunk(prodes2.Text + "\n", font9));
                p10.Alignment = Element.ALIGN_LEFT;
                p10.PaddingTop = 30f;
                doc.Add(p10);
            }

            if (comboBox6.Text != null && pro1.Text != null && prodes1.Text != null)
            {
                Paragraph p9 = new Paragraph(new Chunk("["+comboBox8.Text + "] :" + pro3.Text + "\n", font8)); //add seprate text for the title...
                iTextSharp.text.Font boldFont = FontFactory.GetFont(FontFactory.TIMES_BOLD, 10);

                doc.Add(p9);

                //ADD PROJECT DESCRIPTION 

                BaseFont bf9 = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                iTextSharp.text.Font font9 = new iTextSharp.text.Font(bf9, 14, iTextSharp.text.Font.NORMAL);
                Paragraph p10 = new Paragraph(new Chunk(prodes3.Text, font9));
                p10.Alignment = Element.ALIGN_LEFT;
                p10.PaddingTop = 30f;
                doc.Add(p10);
            }
            
            
            //END OF PROJECTS */


            iTextSharp.text.Font font11 = new iTextSharp.text.Font(bf, 14, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.UNDERLINE);
            BaseFont bf11 = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            Paragraph p13 = new Paragraph(new Chunk(" \n Skills", font11));
            p13.Alignment = Element.ALIGN_LEFT;

            doc.Add(p13);

            List list = new List(List.ORDERED, 20f);
            list.IndentationLeft = 20f;


            if (textBox10.Text != null)
                list.Add(textBox10.Text);
            if (textBox4.Text != null)
                list.Add(textBox4.Text);
            if (textBox9.Text != null)
                list.Add(textBox9.Text);
            if (textBox11.Text != null)
                list.Add(textBox11.Text);


            doc.Add(list);

            //Acheivement tab...
            if (textBox21.Text != null)
            {
                iTextSharp.text.Font font12 = new iTextSharp.text.Font(bf, 14, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.UNDERLINE);
                BaseFont bf12 = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                Paragraph p14 = new Paragraph(new Chunk(" \n Extra Curricular Activities \n", font12));
                p14.Alignment = Element.ALIGN_LEFT;
                doc.Add(p14);
            }
            

            //static tab no need to change..



            List list2 = new List(List.ORDERED, 20f);
            list2.IndentationLeft = 20f;


            if (textBox21.Text != null)
                list2.Add(textBox21.Text);
            if (textBox26.Text != null)
                list2.Add(textBox26.Text);
            if (textBox28.Text != null)
                list2.Add(textBox28.Text);
            if (textBox29.Text != null)
                list2.Add(textBox29.Text);


            doc.Add(list2);


            // 

            Paragraph p15 = new Paragraph(new Chunk(" \n I hereby declare that all the above information is true as per my knowledge ", font));
            p15.Alignment = Element.ALIGN_LEFT;
            doc.Add(p15);


            // p15.Add(FN.Text+" "+MN.Text+" "+LN.Text);
            //doc.Add(p15);

            Paragraph p16 = new Paragraph(new Chunk("\n "+FN.Text + " " + MN.Text + " " + LN.Text, font));
            p16.Alignment = Element.ALIGN_RIGHT;
            doc.Add(p16);


            Paragraph p17 = new Paragraph(new Chunk(" Place: \n Date: ", font));
            p15.Alignment = Element.ALIGN_LEFT;
            doc.Add(p17);


            doc.Close();
            MessageBox.Show("PDF Creted sucessfully \n press ok and check your resume  ");
            System.Diagnostics.Process.Start(folderName + s2 + FN.Text + ".pdf");
           




        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void textBox24_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
        
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void InputForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            
            //if (dialog == DialogResult.Yes)
            //{
            //  Application.Exit();
            //}

            


        }

        private void InputForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Do you really want to exit?", "exit", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.No)

            {
                e.Cancel = true;
            }

            else
            {
                Environment.Exit(0);
            }

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void prodes1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox26_TextChanged(object sender, EventArgs e)
        {

        }

        private void pro1_TextChanged(object sender, EventArgs e)
        {

        }

        private void email_TextChanged(object sender, EventArgs e)
        {

            String z= email.Text;
            bool val = false;

            bool IsValidEmail(String a)
            {
                try
                {
                    var addr = new System.Net.Mail.MailAddress(a);
                    return addr.Address == z;
                }
                catch
                {
                    return false;
                }
            }

            val = IsValidEmail(z);

           /* if(val==false)
            {
                label32.Text = "Something Wrong with Email";
            }
            else
            {
                label32.Text = "";
            }*/


        }

        private void label32_Click(object sender, EventArgs e)
        {

            

        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void objective_TextChanged(object sender, EventArgs e)
        {

        }

        private void label30_Click_1(object sender, EventArgs e)
        {

        }

        private void LN_TextChanged(object sender, EventArgs e)
        {

        }

        private void pro2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pro3_TextChanged(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void InputForm_Leave(object sender, EventArgs e)
        {
            

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label32_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void phno_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void homeadd_TextChanged(object sender, EventArgs e)
        {

        }

        private void streetname_TextChanged(object sender, EventArgs e)
        {

        }

        private void city_TextChanged(object sender, EventArgs e)
        {

        }

        private void state_TextChanged(object sender, EventArgs e)
        {

        }

        private void zipcode_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void country_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void label33_Click(object sender, EventArgs e)
        {
            objectivelists oj = new objectivelists();
            oj.Show();
        }
    }
}
