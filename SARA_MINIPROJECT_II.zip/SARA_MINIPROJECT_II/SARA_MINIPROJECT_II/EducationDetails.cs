﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using iTextSharp.text.pdf.draw;

namespace SARA_MINIPROJECT_II
{
    
    


    public partial class EducationDetails : Form
    {
       

        public EducationDetails()
        {
            InitializeComponent();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           

            Label lbl1 = new Label();
                lbl1.Text = degree.Text;
                lbl1.AutoSize = true;
                lbl1.ForeColor = Color.Black;
                lbl1.Location = new Point(764, 120);
                this.Controls.Add(lbl1);
                lbl1.BringToFront();
        }

        private void EducationDetails_Load(object sender, EventArgs e)
        {

        }

        private void degree_TextChanged(object sender, EventArgs e)
        {

        }
    }

   
}
